SELECT *
  FROM TransactionDetails.Transactions_old
 WHERE CustomerId = 2
