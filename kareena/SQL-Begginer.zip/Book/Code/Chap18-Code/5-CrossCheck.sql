SELECT *
  FROM TransactionDetails.Transactions
 WHERE CustomerId=2
ORDER BY DateEntered DESC
 
