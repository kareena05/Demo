ALTER DATABASE ApressFinancial 
ADD FILE (name='ApressFinancial-Memory', 
filename='C:\APRESS_DEV1\MSSQL12.APRESS_DEV1\MSSQL\DATA\ApressFinancial-Memory') 
TO FILEGROUP [IN-MEMORY-PRIMARY]
