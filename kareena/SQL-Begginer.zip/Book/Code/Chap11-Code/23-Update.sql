USE ApressFinancial
GO
UPDATE CustomerDetails.Customers
SET LastName = 'Mather'
WHERE CustomerId = 7
