DECLARE @IsDate char(15)
SET @IsDate = '31 Sep 2015'
SELECT ISDATE(@IsDate)
