SELECT COUNT(*) AS 'Number of Rows'
FROM ShareDetails.Shares
