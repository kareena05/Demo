DECLARE @WhatsTheDay datetime = '24 March 2015 3:00 PM'
SELECT DATEPART(dd, @WhatsTheDay)
