DECLARE @StringTest char(10)
SET @StringTest = '     Robin'
SELECT RIGHT(@StringTest,3)
