DECLARE @IsDate char(15)
SET @IsDate = '30 Sep 2015'
SELECT ISDATE(@IsDate)
