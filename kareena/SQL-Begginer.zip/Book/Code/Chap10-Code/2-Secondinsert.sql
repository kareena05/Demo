SET QUOTED_IDENTIFIER OFF
GO
INSERT INTO [ApressFinancial].[ShareDetails].[Shares]
           ([Description]
           ,[CurrentPrice])
     VALUES
           ("ACME'S HOMEBAKE COOKIES INC",
            2.34125)
