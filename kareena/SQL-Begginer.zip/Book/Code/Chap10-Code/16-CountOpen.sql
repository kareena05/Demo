   USE ApressFinancial
   go
   SELECT COUNT(*) FROM TransactionDetails.Transactions
