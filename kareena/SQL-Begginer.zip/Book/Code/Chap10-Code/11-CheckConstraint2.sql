INSERT INTO CustomerDetails.CustomerProducts
(CustomerFinancialProductId,CustomerId,FinancialProductId,AmountToCollect,
Frequency,LastCollected,LastCollection)
VALUES (1,1,1,100,0,'24 Aug 2014','23 Aug 2014')
