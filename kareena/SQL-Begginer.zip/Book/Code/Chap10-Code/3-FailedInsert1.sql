USE ApressFinancial
GO
INSERT INTO CustomerDetails.Customers (Title) VALUES ('Mr')
