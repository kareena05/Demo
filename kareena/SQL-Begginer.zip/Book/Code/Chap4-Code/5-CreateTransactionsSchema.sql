USE ApressFinancial
GO
CREATE SCHEMA TransactionDetails AUTHORIZATION dbo
