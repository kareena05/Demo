USE ApressFinancial
GO
CREATE USER [FAT-BELLY-SONY\Apress_Client_Information]
FOR LOGIN [FAT-BELLY-SONY\Apress_Client_Information]
GO
