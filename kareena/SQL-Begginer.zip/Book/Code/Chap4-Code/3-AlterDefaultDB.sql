ALTER LOGIN [FAT-BELLY-SONY\Apress_Product_Controllers]    
WITH DEFAULT_DATABASE=ApressFinancial
