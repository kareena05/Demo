CustomerDetails.apf_InsertCustomer @CustTitle=1,@FirstName='James',
@CustInitials='A',@LastName='McVey',
@AddressLine1='127 Rothsbury Avenue',@AddressLine2='Teguise Coast',
@AddressLine3=NULL,@TownOrCity=94511,@ZipCode='121100',
@USState=0,@AccountTypeId=2,@ClearedBalance=0
