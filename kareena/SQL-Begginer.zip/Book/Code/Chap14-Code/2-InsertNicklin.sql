CustomerDetails.apf_InsertCustomer 1,'Steve',NULL,'Nicklin',
'645 Hyde Park',NULL,NULL,7545,'W1A 1AA',0,1,0
