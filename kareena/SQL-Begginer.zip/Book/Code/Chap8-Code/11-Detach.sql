USE master
GO
sp_detach_db 'ApressFinancial'
