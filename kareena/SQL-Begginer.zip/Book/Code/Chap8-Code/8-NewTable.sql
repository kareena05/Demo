CREATE TABLE TransactionDetails.TransactionHistory
(Column1 varchar(200) NULL,
 Column2 int NULL)
 GO
