ALTER TABLE CustomerDetails.Customers
ALTER COLUMN FirstName nvarchar(100)
