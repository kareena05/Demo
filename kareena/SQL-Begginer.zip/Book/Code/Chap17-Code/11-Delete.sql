DELETE TOP (1) FROM CustomerDetails.FinancialProducts where ProductId = 1

SELECT ProductId,ProductName
FROM CustomerDetails.FinancialProducts
ORDER BY ProductId
