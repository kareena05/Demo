DELETE FROM CustomerDetails.FinancialProducts 
WHERE ProductId < 0
