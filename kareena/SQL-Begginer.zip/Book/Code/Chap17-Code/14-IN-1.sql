SELECT *
  FROM ShareDetails.Shares
 WHERE ShareId IN (1,11,15)
